package com.example.casete_de_alerta;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
public class MainActivity extends AppCompatActivity {
    Button closeButton;
    AlertDialog.Builder builder;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        closeButton = (Button) findViewById(R.id.button);
        builder = new AlertDialog.Builder(this);
        closeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//Uncomment the below code to Set the message and title from the strings.xml file
                builder.setMessage(R.string.dialog_message)
                        .setTitle(R.string.dialog_title);

//Setting message manually and performing action on button click
                AlertDialog.Builder builder = MainActivity.this.builder.setMessage("Doriți să închideți aplicația ?")
                        .setCancelable(false)
                        .setPositiveButton("Da", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {

                            }

                            public void onClick(DialogInterface dialog, int id) {
                                finish();
                                Toast.makeText(getApplicationContext(), "Ai ales Da pentru caseta de alertă",
                                        Toast.LENGTH_SHORT).show();
                            }
                        })
                        .setNegativeButton("Nu", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
// Action for 'NO' Button

                                dialog.cancel();

                                Toast.makeText(getApplicationContext(), "Ai ales Nu pentru caseta de alertă",
                                        Toast.LENGTH_SHORT).show();
                            }
                        });
//Creating dialog box
                AlertDialog alert = MainActivity.this.builder.create();
//Setting the title manually
                alert.setTitle("ExempluAlertDialog");
                alert.show();
            }
        });
    }
}