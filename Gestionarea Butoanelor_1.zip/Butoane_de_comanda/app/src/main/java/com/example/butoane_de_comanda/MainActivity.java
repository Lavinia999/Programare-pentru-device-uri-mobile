package com.example.butoane_de_comanda;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.butoane_de_comanda.R;

public class MainActivity extends AppCompatActivity {
    Button btn1, btn2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btn1 = (Button)findViewById(R.id.btn1); //obținem ID-ul butonului 1

        Button btn2 = (Button)findViewById(R.id.btn2); //obținem ID-ul butonului 2

// prelucrăm evenimentul de apăsare a butonului 1
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"Butonul 1",
                        Toast.LENGTH_LONG).show(); //afișăm textul corespunzător butonului 1
            }
        });
        // prelucrăm evenimentul de apăsare a butonului 2
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"Butonul 2",
                        Toast.LENGTH_LONG).show();////afișăm textul corespunzător butonului 2
            }
        });
    }
}