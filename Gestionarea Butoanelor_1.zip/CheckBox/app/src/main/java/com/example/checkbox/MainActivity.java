package com.example.checkbox;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;
public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void calculeaza(View view) {
//int pr, num;
        double cost;
        String str="";
        TextView p =(TextView) findViewById(R.id.pret);
        TextView nu =(TextView) findViewById(R.id.nr);
        CheckBox reduc = (CheckBox) findViewById(R.id.reducere);
        int pr = Integer.parseInt(p.getText().toString());
        int num = Integer.parseInt(nu.getText().toString());
        cost = pr * num;
        if (reduc.isChecked()) {cost = cost*0.9;}
        String rez = "COSTUL este acesta: "+cost;
        Toast.makeText(getApplicationContext(),rez,
                Toast.LENGTH_LONG).show();
    }
}
