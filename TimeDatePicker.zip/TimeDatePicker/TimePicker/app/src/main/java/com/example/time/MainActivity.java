package com.example.time;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.example.timepicker.R;

public class MainActivity extends AppCompatActivity {
    TextView time;
    TimePicker timePicker;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

// inițializarea interfeței
        time = (TextView) findViewById(R.id.time);
        timePicker = (TimePicker) findViewById(R.id.timePicker);
        timePicker.setIs24HourView(true); // afișează modului 24 ore
//inițializează setOnTimeChangedListener
        timePicker.setOnTimeChangedListener(new TimePicker.OnTimeChangedListener() {
                                                        @Override
                                                        public void onTimeChanged(TimePicker view, int hourOfDay,
                                                                                  int minute) {
// afișează un mesaj toast cu valorile modificate ale selectorului de timp
                                                            Toast.makeText(getApplicationContext(), hourOfDay + " " + minute, Toast.LENGTH_LONG).show();
                                                                    time.setText("Este ora: " + hourOfDay + " : " + minute);
                                                                    // setează ora curentă în caseta de text
                                                        }
                                                    });
    }
}