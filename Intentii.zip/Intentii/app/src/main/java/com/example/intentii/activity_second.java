package com.example.intentii;

import android.app.Activity;

public class activity_second extends Activity {
}
