package com.example.ciclul_de_viata;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.d("Ciclul de viata", "este apelata metoda onCreate");
    }
    @Override
    protected void onStart(){
        super.onStart();
        Log.d("Ciclul de viata", "este apelata metoda onStart");
    }
    @Override
    protected void onResume() {
        super.onResume();
        Log.d("Ciclul de viata", "este apelata metoda onResume");
    }
    @Override
    protected void onPause() {
        super.onPause();
        Log.d("Ciclul de viata", "este apelata metoda onPause");
    }
    @Override
    protected void onStop() {
        super.onStop();
        Log.d("Ciclul de viata", "este apelata metoda onStop");
    }
    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d("Ciclul de viata", "este apelata metoda onRestart");
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d("Ciclul de viata", "este apelata metoda onDestroy");
    }
}