package com.example.casetacusugestii;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;

public class MainActivity extends AppCompatActivity {
    String[] disciplina = {"Matematica", "Informatica",
    "BioInformatica", "Biologia", "Chimia", "Fizica", "Engleza", "Romana", "Istoria", "Geologia", "Geografia"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Crearea adaptorului
        ArrayAdapter<String> adapter = new ArrayAdapter<String>
                (this, android.R.layout.select_dialog_item, disciplina);
        //Cream accesul la caseta
        AutoCompleteTextView actv =
                (AutoCompleteTextView) findViewById(R.id.Caseta1);
        //va afisa lista de sugestii imediat
        //ce primul caracter va fi cules
        actv.setThreshold(1);
        //alegem adaptarul pentru caseta actv
        actv.setAdapter(adapter);
        //setarea culorii textuleui cules in caseta
        actv.setTextColor(Color.BLUE);
    }
}