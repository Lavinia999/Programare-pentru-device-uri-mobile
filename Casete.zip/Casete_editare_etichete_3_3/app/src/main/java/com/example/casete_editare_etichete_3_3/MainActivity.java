package com.example.edittextexample;
import 7ndroid.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.casete_editare_etichete_3_3.Completați;

public class MainActivity extends AppCompatActivity {
    // Declaram variable prin care vom crea accesul la componente
    Button btnSubmit;
    EditText nume, prenume, datanasterii, email, telefon;
    TextView result;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
// Cream acces la continutul fiecarei casete
        nume=(EditText)findViewById(R.id.txtNume);
        prenume = (EditText)findViewById(R.id.txtPren);
        datanasterii = (EditText)findViewById(R.id.txtDate);
        email = (EditText)findViewById(R.id.txtEmail);
        telefon= (EditText)findViewById(R.id.txtTel);
        btnSubmit = (Button)findViewById(R.id.btnSend);
        result = (TextView)findViewById(R.id.resultView);
// Prelucram evenimentul de apasare a butonului
        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
// Verificam ca fiecare caseta sa fie completata
                if (nume.getText().toString().isEmpty() ||
                        prenume.getText().toString().isEmpty() ||
                        email.getText().toString().isEmpty() ||
                        datanasterii.getText().toString().isEmpty()||
                        telefon.getText().toString().isEmpty())
                {
                    result.setText(“Completați toate câmpurile!”);
                } else
                {
                    result.setText(“Nume - “ +
                            nume.getText().toString() + “ \n” + “Prenume - “ +
                        prenume.getText().toString()+ “ \n” + “E-Mail - “ +
                        email.getText().toString() + “ \n” + “Data nașterii - “ +
                        datanasterii.getText().toString() + “ \n” + “Telefon - “
                    + telefon.getText().toString());
                }
            }
        });
    }
}