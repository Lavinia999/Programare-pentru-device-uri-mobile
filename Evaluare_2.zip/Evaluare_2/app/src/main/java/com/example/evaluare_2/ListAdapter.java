package com.example.evaluare_2;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class ListAdapter extends ArrayAdapter<String> {
    LayoutInflater layoutInflater;

    public ListAdapter(Context context) {
        super(context,
                R.layout.list_view);
        layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }
    public void setData(List<String> listaNoua){
        clear();
        addAll(listaNoua);
        notifyDataSetChanged();
        }
@NonNull
@Override
public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
    View view;
    if (convertView == null) {
        view = layoutInflater.inflate(R.layout.list_view, parent, false);
    } else {
        view = convertView;
    }
    TextView textView = view.findViewById(R.id.textView);
    String elementulCurent = getItem(position);
    textView.setText(elementulCurent);
    return view;
    }
}
