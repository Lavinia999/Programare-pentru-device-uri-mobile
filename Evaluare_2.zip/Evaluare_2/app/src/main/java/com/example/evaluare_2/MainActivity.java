package com.example.evaluare_2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends FragmentActivity {
    public String textActivity = "text din activity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        List<String> listaNoua = new ArrayList<>();

        listaNoua.add("Primul Element");
        listaNoua.add("Al Doilea Element");
        listaNoua.add("Al Treilea Element");
        listaNoua.add("Al Patrulea Element");
        listaNoua.add("Al Cincilea Element");

        ListView listView = findViewById(R.id.listView);

        ListAdapter adapter = new ListAdapter(this);
        adapter.setData(listaNoua);

        listView.setAdapter(adapter);
        Button button = findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener(){
        @Override
        public void onClick(View v){
            Intent newIntent = new Intent( MainActivity.this, Main2Activity.class);
            startActivity(newIntent);
        }
        });
    }
}