package com.example.evaluare_2;

import android.os.Bundle;
import android.widget.GridView;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class Main2Activity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        List<String> listaNoua = new ArrayList<>();

        listaNoua.add("Primul Element");
        listaNoua.add("Al Doilea Element");
        listaNoua.add("Al Treilea Element");
        listaNoua.add("Al Patrulea Element");
        listaNoua.add("Al Cincilea Element");

        GridView listView = findViewById(R.id.gridView);

        ListAdapter adapter = new ListAdapter(this);
        adapter.setData(listaNoua);

        listView.setAdapter(adapter);
    }
}
