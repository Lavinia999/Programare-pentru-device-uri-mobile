package com.example.butoane_cu_imagini;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;
public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
// inițiați view
        ImageButton imageButton1 =
                (ImageButton)findViewById(R.id.imageButton1);
        ImageButton imageButton2 =
                (ImageButton)findViewById(R.id.imageButton2);
// executați un clic pe buton
        imageButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"Butonul Apple",Toast.LENGTH_LONG).show();// afișează textul accesând butonul Apple
            }
        });
        imageButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"Butonul wifi",Toast.LENGTH_LONG).show();// afișează textul accesând butonul WiFi
            }
        });
    }
}